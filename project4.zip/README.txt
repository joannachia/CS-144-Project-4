team: Kevanna

autoSuggest.js is taken from http://www.cs.ucla.edu/classes/winter15/cs144/projects/javascript/autosuggest2.js
by Nicholas C. Zakas from the example on the mirror link.